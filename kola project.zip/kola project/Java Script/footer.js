// Handle subscription form submission
document.getElementById('subscribe-form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thank you for subscribing!');
  });
  